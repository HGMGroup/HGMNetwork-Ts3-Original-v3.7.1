update custom_fields set value=:value: where server_id=:server_id: and client_id=:client_id: and ident=:ident:;
