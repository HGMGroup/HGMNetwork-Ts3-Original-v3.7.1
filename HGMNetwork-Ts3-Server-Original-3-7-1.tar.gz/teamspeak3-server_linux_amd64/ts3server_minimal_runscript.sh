#!/bin/sh

D1=$(readlink -f "$0")
D2=$(dirname "${D1}")
cd "${D2}"
exec ./ts3server $@
